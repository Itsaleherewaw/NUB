<style>
#boton-chat {
    position: fixed; right: 25px; bottom: 25px;
    z-index: 5000; background: #ad324b; color: #fff; border: none;
    border-radius: 50%; width: 58px; height: 58px; font-size: 32px; cursor: pointer; box-shadow: 0 3px 15px rgba(0,0,0,0.08);
}
</style>
<button id="boton-chat" onclick="window.location.href='/chat'">💬</button>